# DSA Assignment – Stack and Circular Queue

This repository contains solutions for the DSA assignment using arrays in C.

## Contents

- `stack.c` — Stack implementation using an array
- `circular_queue.c` — Circular Queue implementation using an array

## Q1. Stack Using Array

Operations:
- PUSH(x)
- POP()
- PEEK()
- DISPLAY()

The program handles:
- Stack Overflow
- Stack Underflow

### Complexity

| Operation | Time | Extra Space |
|---|---:|---:|
| PUSH | O(1) | O(1) |
| POP | O(1) | O(1) |
| PEEK | O(1) | O(1) |
| DISPLAY | O(n) | O(1) |

If the fixed-size stack is full and another element is inserted, Stack Overflow occurs.

## Q2. Circular Queue Using Array

Operations:
- ENQUEUE(x)
- DEQUEUE()
- FRONT()
- DISPLAY()

The implementation distinguishes between a full and an empty queue.

### Complexity

| Operation | Time | Extra Space |
|---|---:|---:|
| ENQUEUE | O(1) | O(1) |
| DEQUEUE | O(1) | O(1) |
| FRONT | O(1) | O(1) |
| DISPLAY | O(n) | O(1) |

### Circular Queue vs Linear Queue

A circular queue uses freed positions at the beginning of the array by wrapping the rear pointer around. This provides better memory utilization.

In a linear queue, when `REAR` reaches the last index, insertion may stop even when unused positions exist at the beginning. This is called **false overflow**.

### Overall Space Complexity

For a queue or stack of capacity `n`, the array requires **O(n)** space.

## How to Compile and Run

### Stack

```bash
gcc stack.c -o stack
./stack
```

### Circular Queue

```bash
gcc circular_queue.c -o circular_queue
./circular_queue
```

## Author

DSA Assignment
